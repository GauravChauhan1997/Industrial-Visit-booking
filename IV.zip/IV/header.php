<?php include("libs/config.php")?>	
<?php

if(isset($_POST["submit"]))
{
	$fullname = $_POST["fullname"];
	$email = $_POST["email"];
	$contact = $_POST["contact"];
	$dept = $_POST["dept"];
	$branch = $_POST["branch"];
	$status = '0';
	$createddate = date('d-M-Y');
	
	$query = "INSERT INTO `booknow`(`fullname`, `email`, `contact`, `dept`, `branch`, `status`, `createddate`) VALUES ('$fullname','$email','$contact','$dept','$branch','$status','$createddate')";
	$que = mysql_query($query);
	if($que)
	{
		echo '<script>alert ("Booking is confirmed")</script>';
	}else{
		echo '<script>alert ("Something Went Wrong")</script>';
	}
}
?>
    <!DOCTYPE <html>
	<head>
		<title>Industrial Visit | Home</title>
		<link rel="stylesheet" href="css/bootstrap.css"/>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<link rel="stylesheet" type="text/css" href="css/style.css"/>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="assets/bootstrap/css/bootstrap.css" rel="stylesheet">
        <link href="assets/css/style.css" rel="stylesheet">
        <link href="assets/css/owl.carousel.css" rel="stylesheet">
        <link href="assets/css/owl.theme.css" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
		<script type="text/javascript"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src='https://www.google.com/recaptcha/api.js'></script>
	</head>
	<body>
		<div class="container-fluid"  style="background-color:white">
		<div class="row">
<div class="col-md-12">
<nav class="navbar" style="background-color:#550003">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#"><img src="img/logo.png" style="margin-top:-10px;margin-left:20px" height="60px" width="70px"></a>
    </div>
    <center><div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav pull-right">
        <li class="active"><a href="index.php" style="color:yellow;margin:12px;font-size:18px;">Home</a></li>      
        <li><a href="about.php" style="color:yellow;margin:12px;font-size:18px;">About</a></li>
        <li><a href="#" style="color:yellow;margin:12px;font-size:18px">Services</a></li>
		<li><a href="gallery.php" style="color:yellow;margin:12px;font-size:18px;">Gallery</a></li>
        <li><a href="#" style="color:yellow;margin:12px;font-size:18px;">Contact</a></li>
		<li><a href="#" style="color:yellow;margin:12px;font-size:18px;" data-toggle="modal" data-target="#myModal">Book Now</a></li>
      </ul>
    </div></center>
</nav>
</div>
</div> 
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm" style="width:335px">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="background-color:#550003;font-weight:bold; font-family: Verdana;color:white">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Book Now</h4>
        </div>
        <div class="modal-body">
		  <form method="POST">
          <div class="row">
		     <div class="col-md-12">
			       <div class="form-group">
			           <input type="text" class="form-control" name="fullname" id="fullname" placeholder="Full Name" required />
			       </div>
				    <div class="form-group">
			           <input type="text" class="form-control" name="email" id="email" placeholder="Email" required />
			       </div>
				   <div class="form-group">
			           <input type="number" class="form-control" name="contact" id="contact" placeholder="Contact number" required />
			       </div>
				   <div class="form-group">
			           <select class="form-control" name="dept" id="dept" required>
					        <option>-- Select Department--</option>
<?php
$abc2 = mysql_query("SELECt * FROM pdf ORDER BY pdfid");
while($abcd3 = mysql_fetch_array($abc2))
{
?>
					        <option value="<?php echo $abcd3["pdfid"]?>"><?php echo $abcd3["branch"]?></option>
<?php
}
?>
					   </select>
			       </div>
				    <div class="form-group">
			           <select class="form-control" name="branch" id="branch" required>
					        <option>-- Select IV--</option>
<?php
$abc = mysql_query("SELECt * FROM pdf ORDER BY pdfid");
while($abcd = mysql_fetch_array($abc))
{
?>
					        <option value="<?php echo $abcd["pdfid"]?>"><?php echo $abcd["pdftitle"]?></option>
<?php
}
?>
					   </select>
			       </div>
                    <p>
			           <button type="submit" class="btn btn-info" name="submit" id="submit" style="width:100%">Book Now</button>
			       </p>			
			 </div>
		  </div>
		  </form>
        </div>
      </div>
      
    </div>
</div>
