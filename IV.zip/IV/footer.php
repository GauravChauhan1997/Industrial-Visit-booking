<br><br><br>
<div class="col-md-12" style="background-color:#550003; color:white"><br><center>©2018 Pillai HOC College of Engineering and Technology(PHCET).  All Rights Reserved.</center><br></div>

					


				</div>
			</body>
			</html>
<script>
function recaptcha_callback(){
	var recaptchabtn = document.querySelector('#submit');
	recaptchabtn.removeAttribute('disabled');
	recaptchabtn.style.cursor = 'pointer';
}
</script>