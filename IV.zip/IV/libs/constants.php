<?php

// database prefix if you use
define('DB_PREFIX', 'mp1_');

define('DB_SERVER', 'localhost');
define('DB_SERVER_USERNAME', 'root');
define('DB_SERVER_PASSWORD', '');
define('DB_DATABASE', 'ip2');



?>