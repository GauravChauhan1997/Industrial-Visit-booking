<?php include("header.php")?>

<?php
     if(isset($_POST["pdf_submit"]))
	 {
		 $branch = $_POST["branch"];
		 $pdftitle = $_POST["pdftitle"];
		 $status = '0';
		 $createddate = date("d-M-Y");
		 $profile_image = $_FILES["fruit_img"]["name"];
	$characters = 'abc123';
	$string = '';
	$string1 = '';
	$string2 = '';
	$string6 = '';
	if($profile_image <> "")
	{

		for($j = 0; $j < count($profile_image); $j++)
		{
		for($i = 0; $i < 0; $i++) {
			$string .= $characters[rand(0, strlen($characters) - 1)];
		}	
		$profile_imagePath = "pdfs/" . $string . $profile_image[$j];

		move_uploaded_file($_FILES["fruit_img"]["tmp_name"][$j], $profile_imagePath);
		}
	}
		 
		 $query = "INSERT INTO `pdf` (`branch`,`pdftitle`, `pdfurl`, `status`, `createddate`) VALUES ('$branch','$pdftitle','$profile_imagePath','0','$createddate')";
         $que = mysql_query($query);
		 
         if($que)
		 {
            		echo '<script>alert("Pdf is Added")</script>';
		 }else
         {
			        echo '<script>alert("Something Went wrong")</script>';
		 }			 
	 }

?>
  
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add IV Detail
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            
            <!-- /.box-header -->
            <!-- form start -->
            <form method="post" action="" enctype="multipart/form-data">
              <div class="box-body">
			    <div class="row"><br>
			     <div class="col-md-12">
			        <div class="form-group col-md-4">
                    </div>

                    <div class="form-group col-md-4">
						   <label>Branch</label><br>                         
						  <select class="form-control" name="branch" id="branch">
						       <option value="IT/COM">IT/COMPUTER</option>
							   <option value="CIVIL/MECH">CIVIL/MECHANICAL</option>
							   <option value="EXTC">EXTC</option>
						  </select><br>
                          <label>Title</label><br>
                          <input type="text" class="form-control" name="pdftitle" id="pdftitle" placeholder="Enter Title"/><br>
                          <label>PDF</label><br>
                          <input type="file" name="fruit_img[]" />	
               
                    </div>
                    <div class="form-group  col-md-4">                        
                    </div>
			     </div>
			  </div>
              </div>
			  
              <div class="box-footer">
			    <center>
			    <button type="submit" class="btn btn-primary" name="pdf_submit" id="pdf_submit">Submit</button>
                <button type="submit" class="btn btn-warning">Reset</button>
				</center>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
		
		
        
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
  <?php include("footer.php")?>