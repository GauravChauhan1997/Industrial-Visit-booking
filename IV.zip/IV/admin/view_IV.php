<?php include("header.php")?>
<?php
    if (isset($_REQUEST["del"]) && $_REQUEST["del"] != "" ) 
		{
			$del = $_REQUEST["del"];
			$query = "DELETE FROM pdf WHERE `pdfid` = ".$_REQUEST["del"];			
			
			$stmt = mysql_query($query);
			if ($stmt) 
			{
				
				
						echo("<script type='text/javascript'>
						
							alert('Deleted');
					
						</script>");
					
			}
			else 
			{
				
				echo("<script type='text/javascript'>
					
					alert('Not Deleted');
					
						</script>");
				
			}	
		}

?>


<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        IV Records
        <small>advanced tables</small>
      </h1>
      
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
				  <th><input type="checkbox"/></th>
				  <th>Sr no.</th>
                  <th>Title</th>
                  <th>Branch</th>
                  <th>PDF</th>
                  <th>Created Date</th>
                </tr>
                </thead>
                <tbody>
<?php
 $count = 1;
   $query = mysql_query("select * from pdf order by pdfid desc");
   
   while($row = mysql_fetch_array($query))
   {
	   
?>
                <tr>
				  <td><input type="radio" name="chkNumber" class="chkNumber" value="<?php echo $row["pdfid"]?>"></td>
				  <td><?php echo $count?></td>
                  <td><?php echo $row["pdftitle"]?> </td>
                  <td><?php echo $row["branch"]?></td>
                  <td><?php echo $row["pdfurl"]?></td>
				  <td><b style="color:green"><?php echo $row["createddate"]?></b></td>
                </tr>
<?php
$count++;
   }
?>
				
              </tbody>
              </table><br>
              <button type="submit" class="btn btn-danger" id="delete" name="delete">Delete</button>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
	
    <!-- /.content -->
  </div>
<?php include("footer.php")?>

<script>
 $(document).on("click","#delete",function(e){
		
			if ($('.chkNumber:checked').length) {
				  var chkId = '';
				  $('.chkNumber:checked').each(function () {
					chkId += $(this).val() + ",";
				  });
				  chkId = chkId.slice(0, -1);
				 //alert(chkId);
				 location.href = "view_IV.php?del=" + chkId ;
				}
				else {
				  alert('Nothing Selected');
				}
			
		});
</script>
