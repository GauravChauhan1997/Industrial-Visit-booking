<?php include("header.php")?>

<div class="container-fluid">
  <h2 style="color:red">EXTC</h2>
  <hr>

        <center><h2>PDF</h2></center>
	    <div class="row">
		    <div class="col-md-12">
			     <table class="table table-bordered">
    <thead>
      <tr>
        <th>Sr No.</th>
        <th>Title</th>
        <th>PDF</th>
		<th>Created Date</th>
      </tr>
    </thead>
     <tbody>
<?php
 $count = 1;
   $query = mysql_query("select * from pdf WHERE branch = 'EXTC' order by pdfid desc");
   
   while($row = mysql_fetch_array($query))
   {
	   
?>
      <tr>
        <td><?php echo $count?></td>
        <td><?php echo $row["pdftitle"]?> </td>
		<td><a href="admin/<?php echo $row["pdfurl"]?>" download>Download PDF</a></td>
		<td><?php echo $row["createddate"]?></b></td>
      </tr>
<?php
$count++;
   }
?>
    </tbody>
  </table>
			</div>
		</div><br>
  </div>
</div>


					
						

<?php include("footer2.php")?>