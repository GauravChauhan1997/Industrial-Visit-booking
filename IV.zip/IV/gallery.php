<?php include("header.php")?>
<div class="container-fluid">
 <div class="row">
	  <div class="col-md-12">
	      <center class="title_heading"><h2>GALLERY</h2></center>
     </div>
 </div><hr style="margin-top:-0px">	 
 <div class="row" style="margin-top:30px">
      <div class="col-md-12">
	       <div class="col-md-3"><img src="img/1.jpeg" class="img-responsive image" height="200px" width="100%"/></div>
		   <div class="col-md-3"><img src="img/2.jpeg" class="img-responsive image" height="200px" width="100%"/></div>
           <div class="col-md-3"><img src="img/3.jpeg" class="img-responsive image" height="200px" width="100%"/></div>
           <div class="col-md-3"><img src="img/4.jpeg" class="img-responsive image" height="200px" width="100%"/></div>		   	   
	  </div>	  
 </div>
 <div class="row" style="margin-top:30px">
      <div class="col-md-12">
	       <div class="col-md-3"><img src="img/5.jpeg" class="img-responsive image" height="200px" width="100%"/></div>
		   <div class="col-md-3"><img src="img/4.jpeg" class="img-responsive image" height="200px" width="100%"/></div>
           <div class="col-md-3"><img src="img/7.jpeg" class="img-responsive image" height="200px" width="100%"/></div>
           <div class="col-md-3"><img src="img/1.jpeg" class="img-responsive image" height="200px" width="100%"/></div>		   	   
	  </div>	  
 </div>
 <div class="row" style="margin-top:30px">
      <div class="col-md-12">
	       <div class="col-md-3"><img src="img/9.jpeg" class="img-responsive image" height="200px" width="100%"/></div>
		   <div class="col-md-3"><img src="img/1.jpeg" class="img-responsive image" height="200px" width="100%"/></div>		   	   
	  </div>	  
 </div>
</div>
<?php include("footer.php")?>