<?php include("header.php")?>
<div class="container-fluid">
 <div class="row">
	  <div class="col-md-12">
	      <center class="title_heading"><h2>ABOUT US</h2></center>
     </div>
 </div><hr style="margin-top:-0px">	 
 <div class="row" style="margin-top:30px">
      <div class="col-md-12">
	       <div class="col-md-6" style="line-height: 25px;font-size: 17px;color: #444449">Quid dubitas igitur mutare principia naturae? Negat enim summo bono afferre incrementum diem. Quamquam id quidem, infinitum est in hac urbe; 
		   Dolere malum est: in crucem qui agitur, beatus esse non potest. Duo enim genera quae erant, fecit tria. 
		   O magnam vim ingenii causamque iustam, cur nova existeret disciplina! Perge porro. Hic ambiguo ludimur. 
		   Iubet igitur nos Pythius Apollo noscere nosmet ipsos. Philosophi autem in suis lectulis plerumque moriuntur.
		   Neque solum ea communia, verum etiam paria esse dixerunt. 
		   Quicquid porro animo cernimus, id omne oritur a sensibus.
		   Quid dubitas igitur mutare principia naturae? Negat enim summo bono afferre incrementum diem.
		   Iubet igitur nos Pythius Apollo noscere nosmet ipsos. Philosophi autem in suis lectulis plerumque moriuntur.
		   Neque solum ea communia, verum etiam paria esse dixerunt. 
		   Quicquid porro animo cernimus, id omne oritur a sensibus.
		   Quid dubitas igitur mutare principia naturae? Negat enim summo bono afferre incrementum diem.</div>
		   <div class="col-md-6"><iframe width="560" height="315" src="https://www.youtube.com/embed/aEgsjV31IyI" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe></div>
	  </div>
 </div>
</div>
<?php include("footer.php")?>